# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class FirebaseUserInfo(Component):
    """A FirebaseUserInfo component.


Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- apiToken (string; default ''):
    The JWT token for the currently logged in user, for API access.

- userDisplayName (string; default ''):
    The display name of the logged in user, or blank.

- userEmail (string; default ''):
    The email of the logged in user, or blank.

- userPhotoUrl (string; default ''):
    A URL to a photo for the user, or blank."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'firebase_authentication'
    _type = 'FirebaseUserInfo'
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, userDisplayName=Component.UNDEFINED, userEmail=Component.UNDEFINED, userPhotoUrl=Component.UNDEFINED, apiToken=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'apiToken', 'userDisplayName', 'userEmail', 'userPhotoUrl']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'apiToken', 'userDisplayName', 'userEmail', 'userPhotoUrl']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(FirebaseUserInfo, self).__init__(**args)
